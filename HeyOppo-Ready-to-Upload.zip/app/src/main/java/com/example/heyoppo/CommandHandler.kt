package com.example.heyoppo

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract.CommonDataKinds.Phone

object CommandHandler {
    private fun enc(s: String) = Uri.encode(s)

    private fun launch(ctx: Context, i: Intent, ok: String): String =
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); ok }
        catch (e: Exception) { "Sorry, I couldn't do that" }

    private fun number(ctx: Context, name: String): String? {
        if (name.none { it.isLetter() }) {
            val d = name.filter { it.isDigit() || it == '+' }
            if (d.length >= 5) return d
        }
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        ctx.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    fun handle(ctx: Context, raw: String): String {
        val t = raw.lowercase().trim()

        Regex("subscribe(?: to)? (.+?)(?: channel)?$").find(t)?.let {
            val n = it.groupValues[1]
            return launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(
                "https://www.youtube.com/results?search_query=${enc(n)}&sp=EgIQAg%253D%253D")),
                "Opening $n on YouTube. Tap Subscribe.")
        }
        (Regex("(?:search|play|find) (.+?) on youtube").find(t)
            ?: Regex("(?:search|play|find) youtube (?:for )?(.+)").find(t))?.let {
            val q = it.groupValues[1]
            return launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(
                "https://www.youtube.com/results?search_query=${enc(q)}")), "Searching YouTube for $q")
        }
        Regex("(?:navigate|directions?|take me) to (.+)").find(t)?.let {
            return launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${enc(it.groupValues[1])}")),
                "Navigating to ${it.groupValues[1]}")
        }
        Regex("(?:call|dial|phone) (.+)").find(t)?.let {
            val n = number(ctx, it.groupValues[1]) ?: return "I couldn't find ${it.groupValues[1]} in your contacts"
            val act = if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED)
                Intent.ACTION_CALL else Intent.ACTION_DIAL
            return launch(ctx, Intent(act, Uri.parse("tel:$n")), "Calling ${it.groupValues[1]}")
        }
        (Regex("whats ?app (.+?) (?:saying|that|message) (.+)").find(t))?.let {
            val n = number(ctx, it.groupValues[1]) ?: return "I couldn't find ${it.groupValues[1]} in your contacts"
            return launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(
                "https://wa.me/${n.filter { c -> c.isDigit() }}?text=${enc(it.groupValues[2])}")),
                "Opening WhatsApp for ${it.groupValues[1]}")
        }
        (Regex("(?:message|text|sms) (.+?) (?:saying|that|with) (.+)").find(t)
            ?: Regex("(?:message|text|sms) (.+)").find(t))?.let {
            val n = number(ctx, it.groupValues[1]) ?: return "I couldn't find ${it.groupValues[1]} in your contacts"
            val body = if (it.groupValues.size > 2) it.groupValues[2] else ""
            return launch(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", body),
                "Messaging ${it.groupValues[1]}. Tap send.")
        }
        Regex("^(?:open|launch|start) (.+)").find(t)?.let {
            val name = it.groupValues[1].replace(" ", "")
            val pm = ctx.packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = apps.firstOrNull { a -> a.loadLabel(pm).toString().lowercase().replace(" ", "").contains(name) }
            pm.getLaunchIntentForPackage(hit?.activityInfo?.packageName ?: "")?.let { i ->
                return launch(ctx, i, "Opening ${it.groupValues[1]}")
            }
            return "I couldn't find an app called ${it.groupValues[1]}"
        }
        Regex("(?:search|google|look up)(?: for)? (.+)").find(t)?.let {
            return launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${enc(it.groupValues[1])}")),
                "Searching for ${it.groupValues[1]}")
        }
        return "Sorry, I didn't get that"
    }
}
