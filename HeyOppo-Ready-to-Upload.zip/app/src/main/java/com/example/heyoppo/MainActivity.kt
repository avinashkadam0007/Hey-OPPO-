package com.example.heyoppo

import android.Manifest.permission.*
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 120, 48, 48) }
        fun add(v: View) = col.addView(v)
        add(TextView(this).apply { text = "Hey Oppo Assistant"; textSize = 26f })
        add(TextView(this).apply {
            setPadding(0, 24, 0, 24)
            text = "Say “Hey Oppo” then a command:\n• open YouTube\n• search YouTube for songs\n• subscribe to MrBeast channel\n• call Mom\n• message Mom saying I’m late\n• WhatsApp Mom saying hello\n• navigate to Central Park\n• search for best phones"
        })
        add(Button(this).apply { text = "Enable & Start"; setOnClickListener { begin() } })
        add(Button(this).apply { text = "Stop"; setOnClickListener { stopService(Intent(context, ListenService::class.java)) } })
        add(Button(this).apply { text = "Battery: allow background"; setOnClickListener { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun begin() {
        val perms = mutableListOf(RECORD_AUDIO, READ_CONTACTS, CALL_PHONE)
        if (Build.VERSION.SDK_INT >= 33) perms.add(POST_NOTIFICATIONS)
        val missing = perms.filter { checkSelfPermission(it) != PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1) else proceed()
    }

    private fun proceed() {
        if (checkSelfPermission(RECORD_AUDIO) != PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission is required", Toast.LENGTH_LONG).show(); return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow “Display over other apps”, then tap Enable & Start again", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        startForegroundService(Intent(this, ListenService::class.java))
        Toast.makeText(this, "Listening. Say “Hey Oppo”", Toast.LENGTH_LONG).show()
    }

    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) { proceed() }
}
