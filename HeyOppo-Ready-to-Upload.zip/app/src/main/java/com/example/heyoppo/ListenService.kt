package com.example.heyoppo

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class ListenService : Service(), RecognitionListener {
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var awake = false
    private var handled = false
    private var running = false
    // Add or change wake phrases here
    private val wakeWords = listOf("hey oppo", "hey opo", "hi oppo", "hey opp", "a oppo")

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("ho", "Assistant", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "ho").setContentTitle("Hey Oppo is listening")
            .setContentText("Say “Hey Oppo”, then your command")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        tts = TextToSpeech(this) { s -> if (s == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (!running) { running = true; listen() }
        return START_STICKY
    }

    private fun listen() {
        if (!running) return
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(this@ListenService) }
        handled = false
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        rec?.startListening(i)
    }

    private fun next(ms: Long) { main.postDelayed({ listen() }, ms) }
    private fun speak(s: String) { tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "ho") }

    private fun process(text: String, final: Boolean) {
        if (handled || text.isBlank()) return
        val t = text.lowercase().trim()
        if (awake) {
            if (final) { handled = true; awake = false; speak(CommandHandler.handle(this, t)); next(2500) }
            return
        }
        var start = -1; var end = -1
        for (w in wakeWords) {
            val i = t.indexOf(w)
            if (i >= 0 && (start < 0 || i < start)) { start = i; end = i + w.length }
        }
        if (start < 0) { if (final) { handled = true; next(300) }; return }
        val rest = t.substring(end).trim()
        if (rest.isEmpty()) { handled = true; awake = true; rec?.cancel(); speak("Yes?"); next(1200) }
        else if (final) { handled = true; speak(CommandHandler.handle(this, rest)); next(2500) }
    }

    override fun onPartialResults(b: Bundle?) {
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { process(it, false) }
    }
    override fun onResults(b: Bundle?) {
        val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (t != null) process(t, true) else if (!handled) { handled = true; awake = false; next(300) }
    }
    override fun onError(e: Int) {
        if (handled) return
        handled = true
        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
        awake = false
        next(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 2000 else 400)
    }
    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(r: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onEvent(t: Int, b: Bundle?) {}
    override fun onBind(i: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        rec?.destroy(); tts?.shutdown()
        super.onDestroy()
    }
}
